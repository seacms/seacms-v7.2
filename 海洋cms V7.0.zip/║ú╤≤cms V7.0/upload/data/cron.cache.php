<?php
//ssea2.0 cache file
//Created on 2012-12-13 10:39:31

if(!defined('sea_INC')) exit('Access Denied');

$cronnextrun = '1355369940';

?>