<?php
//MYSQL Char
$dbcharr=Array(
	'0'=>'utf8'
	);

//Language
$langcharr=Array(
	'0'=>'gbutf8,utf-8,Chinese simplified'
	);
?>