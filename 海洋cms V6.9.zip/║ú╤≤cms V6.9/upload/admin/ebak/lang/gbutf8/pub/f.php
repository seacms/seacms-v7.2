<?php
$fun_r=array();
$fun_r=Array(
	'StartToBak'=>'初始化备份成功，正在进入表备份．．．．．．',
	'OneTableBakSuccOne'=>'备份 ',
	'OneTableBakSuccTwo'=>' 表成功，正在进入下一个表备份．．．．．．',
	'BakOneDataSuccess'=>'备份一组数据成功，正在进入下一组．．．．．．',
	'GotoDefaultDb'=>'正转到默认的数据库,请稍等......',
	'ConntConnectDb'=>'链接不上MYSQL，请设置好数据库相关设置，<a href=SetDb.php><b><u>点击此处</u></b></a>进行设置操作',
	'OneTableReSuccOne'=>'还原 ',
	'OneTableReSuccTwo'=>' 表完毕，正在进入下一个表还原......',
	'ReOneDataSuccess'=>'一组数据恢复完毕，正在进入下一组数据......',
	'BakSuccess'=>'恭喜您！备份完毕.',
	'ReDataSuccess'=>'恭喜您！数据还原完毕.',
	'TotalUseTime'=>'共计用时: ',
	'TimeHour'=>' 小时',
	'TimeMinute'=>' 分钟',
	'TimeSecond'=>' 秒'
);
?>