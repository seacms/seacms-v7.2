<?php
function kankan($str)
{
return $str;
}
?>